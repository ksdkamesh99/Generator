package com.example.generator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.generator.R.id.len;

public class pass extends AppCompatActivity {
    Button genpass;
    Button cpy;
    CheckBox splc;
    CheckBox num;
    CheckBox small;
    CheckBox cap;
    EditText len;
   TextView password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass);
        genpass=(Button) findViewById(R.id.genpass);
        cpy=(Button) findViewById(R.id.cpy);
        splc=(CheckBox) findViewById(R.id.splc);
        num=(CheckBox) findViewById(R.id.num);
        small=(CheckBox) findViewById(R.id.small);
        cap=(CheckBox) findViewById(R.id.cap);
        len=(EditText) findViewById(R.id.len);
        password=(TextView) findViewById(R.id.password);
        password.setEnabled(false);
        genpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n="0123456789";
                String sm="qwertyuiopasdfghjklzxcvbnm";
                String cp="QWRTYUIOPASDFGHJKLZXCVBNM";
                String spl="!@#$%^&*()_-+=?></";
                String q=len.getText().toString();
                if(!TextUtils.isEmpty(q)){
                int l=Integer.parseInt(len.getText().toString());
                if( !splc.isChecked() && !num.isChecked() && !small.isChecked() && !cap.isChecked()){
                    Toast.makeText(pass.this,"Tick Atleast One of Options",Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    if(l<=0){
                        Toast.makeText(pass.this,"Password Length must be >=1",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    else{
                        String total;
                        total = "";
                        int y1=0;
                        int y2=0;
                        int y3=0;
                        int y4=0;
                        if(small.isChecked()){
                            total=total+sm;
                            y1++;

                        }
                        if(num.isChecked()){
                            total=total+n;
                            y2++;
                        }
                        if(cap.isChecked()){
                            total=total+cp;
                            y3++;
                        }
                        if(splc.isChecked()){
                            total=total+spl;
                            y4++;
                        }
                        String p="";
                        if(y1==1){
                            int o=sm.length();
                            int yy=(int) (o*Math.random());
                            p = p + sm.charAt(yy);
                        }
                        if(y2==1){
                            int o=n.length();
                            int yy=(int) (o*Math.random());
                            p = p + n.charAt(yy);
                        }
                        if(y3==1){
                            int o=cp.length();
                            int yy=(int) (o*Math.random());
                            p = p + cp.charAt(yy);
                        }
                        if(y4==1){
                            int o=spl.length();
                            int yy=(int) (o*Math.random());
                            p = p + spl.charAt(yy);
                        }
                        int y5=y1+y2+y3+y4;
                        int i;
                        for(i = 0; i<l-y5; i++){
                            int o=total.length();
                            int yy=(int) (o*Math.random());
                            p = p + total.charAt(yy);
                        }
                        password.setText(p);
                        password.setEnabled(false);
                    }
                }
            }
                else{
                    Toast.makeText(pass.this,"Fill the Length"+q,Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
        cpy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text=password.getText().toString();
                if(TextUtils.isEmpty(text)){
                    Toast.makeText(pass.this,"Nothing is There to copy",Toast.LENGTH_SHORT).show();
                    return;
                }
                else{

                    ClipboardManager clipboard=(ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip=ClipData.newPlainText("EditText",text);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(pass.this, "Text Copied",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
