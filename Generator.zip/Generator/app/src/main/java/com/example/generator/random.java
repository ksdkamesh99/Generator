package com.example.generator;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class random extends AppCompatActivity {
    Button gen;
    EditText fr,t;
    TextView ans;

    private static int getRandomNumberInRange(int min, int max) {



        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random);

        gen=(Button) findViewById(R.id.gen);
        ans=(TextView) findViewById(R.id.ans);
        fr=(EditText) findViewById(R.id.fr);
        t=(EditText) findViewById(R.id.t);
        gen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(fr.getText().toString()) || TextUtils.isEmpty(t.getText().toString())){
                    Toast.makeText(random.this, "input fields can't be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    int from=Integer.parseInt(fr.getText().toString());
                    int to=Integer.parseInt(t.getText().toString());
                    if(from>to){
                        Toast.makeText(random.this, "range is incorrect", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    else{
                        int s=getRandomNumberInRange(from,to);
                        ans.setText("Random no generated is "+Integer.toString(s));
                    }
                }
            }
        });

    }
}
