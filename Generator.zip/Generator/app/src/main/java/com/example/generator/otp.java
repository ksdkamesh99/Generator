package com.example.generator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class otp extends AppCompatActivity {
    private static int getRandomNumberInRange(int min, int max) {



        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
    Button genotp;
    TextView aotp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        genotp=(Button) findViewById(R.id.genotp);
        aotp=(TextView) findViewById(R.id.aotp);
        genotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int u=getRandomNumberInRange(1000,9999);
                aotp.setText(Integer.toString(u));
            }
        });

    }
}
